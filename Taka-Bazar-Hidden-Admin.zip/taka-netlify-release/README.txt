TAKA BAZAR — NETLIFY STATIC RELEASE

Deploy:
1) Extract this ZIP.
2) Upload the extracted folder (index.html, version.json, netlify.toml) to Netlify Drop or your Netlify site.
3) Set the Telegram Mini App URL to the Netlify URL.

Auto-update:
The Mini App checks /version.json every 30 seconds. After you publish a new release, change the version value in version.json and redeploy. Mini Apps currently open will reload when they detect the new version; users opening later receive the new files.

No Firebase, database, Render, or backend is included.

IMPORTANT LIMITS:
- Local data is stored in the current browser/device only. It is not shared between users/devices and may be lost if browser data is cleared.
- Admin changes are local-only. Changing task/settings content for every user requires a server/database or redeploying the updated website files.
- Referral balances, withdrawals, and user balances are NOT secure or authoritative without a backend. This static release must not be used for real-money rewards.
- The admin password is local only. Default: change-this-password. After opening admin, change it in the browser console using: localStorage.setItem('taka_admin_password','YOUR_NEW_PASSWORD')
